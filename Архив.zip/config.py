
DB = {
	"host": "localhost",
	"user": "root",
	"password": "",
	"db": "db_course"
}